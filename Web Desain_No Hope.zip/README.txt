Web Design Edufest
Redesign Web Pemerintah Kecamatan Medan Johor
Nama Tim : No Hope
Anggota Nim : 1. Muhammad Fauzan Fadhil Kurnia (222212750) / 1KS4
	      2. Solideo Gracio Bangun (222212888) / 1KS4
Link Situs Asli : https://medanjohor.pemkomedan.go.id/web/
Kelebihan : - Memperbarui tampilan 'Home'
	    - Menambahkan fitur 'Pojok Aduan' yang dapat digunakan masyarakat untuk menyampaikan aspirasi pada halaman home
	    - Memperbarui tampilan header dan footer
	    - Memperbarui tampilan halaman 'Profil' ( Gambaran Umum, Visi Misi, dan Struktur Organisasi)
	    - Memperbarui tampilan halaman berita
	    - Menambahkan fitur komentar pada halaman berita
	    - Menambahkan fitur pencarian berita
	    - Memperbarui tampilan halaman layanan (disertai penggunaan modal)
	    - Menambahkan sebuah tabel agar masyarakat mengetahui sejauh mana layanan mereka telah ditindaklanjuti pada halaman layanan.
	    - Memperbarui tampilan halaman galeri
	    - Menambahkan fitur mengunduh foto
	    - Memperbarui tampilan halaman kelurahan (disertai penggunaan modal)
	    - Memperbarui tampilan halaman prestasi
	    - Memperbarui tampilan halaman pengumuman
	    - Menambahkan fitur mengunduh file pengumuman